Lists
=====

Lists of available options for time zones, keymaps, etc... Formatted in a way that makes them
look not too ugly in less(1).
